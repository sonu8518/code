﻿extern alias oldVer;
extern alias newVer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SameTwoDll
{
    class Program
    {
        static void Main(string[] args)
        {
          

            Console.WriteLine(oldVer::Lib.Class1.method());
            Console.WriteLine(newVer::Lib.Class1.method());
            Console.Read();


     // Run in Console 

           // csc /r:oldVer = C:\Users\sonu8\source\repos\SameTwoDll\path1\Lib.dll /r:newVer = C:\Users\sonu8\source\repos\SameTwoDll\path1\Lib.dll program.cs
        }
    }
}
