﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib
{
    public class Class1
    {
        public static string method()
        {
            //old
          // return "From old version Lib";
            //new
           return "From new version Lib";
        }
    }
}
