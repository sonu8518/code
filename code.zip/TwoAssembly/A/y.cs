﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace A
{
    public abstract class y
    {
        public void Method1()
        {
            Console.WriteLine("Class Y Method1");
        }

    }
}
