﻿using System;
using System.Collections.Generic;
using System.Text;

namespace A
{
    public class x:y
    {
        public void Method2()
        {
            Console.WriteLine("Class x Method2");
        }

    }
}
