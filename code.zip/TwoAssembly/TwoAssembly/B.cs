﻿using A;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace B
{
    class B
    {
        static void Main(string[] args)
        {
            //•	Declare 2 Classes (X and Y) in Assembly A both classes should be accessible in Assembly B.
            x objx = new x();
            objx.Method2();
        
          

            //•	But restrict the instantiation of class Y in Assembly B. 
            objx.Method1();
            Console.Read();


        }
    }


}
